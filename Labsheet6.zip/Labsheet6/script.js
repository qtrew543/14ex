let currentLevel = 1; // Start at level 1
const levels = document.querySelectorAll('.level');
const pathLines = document.querySelectorAll('.path-line');
const avatar = document.getElementById('avatar');
const progressBar = document.querySelector('.progress-bar');

// Confetti effect
const createConfetti = () => {
  const confettiCount = 30;
  for (let i = 0; i < confettiCount; i++) {
    const confetti = document.createElement('div');
    confetti.classList.add('confetti');
    confetti.style.left = `${Math.random() * window.innerWidth}px`;
    confetti.style.animationDelay = `${Math.random() * 2}s`;
    document.body.appendChild(confetti);

    // Remove confetti after animation
    setTimeout(() => {
      confetti.remove();
    }, 2000);
  }
};

// Update the progress bar
const updateProgressBar = () => {
  const progress = (currentLevel / levels.length) * 100;
  progressBar.style.width = `${progress}%`;
};

// Update levels and path lines
const updateLevels = () => {
  levels.forEach((level, index) => {
    if (index < currentLevel - 1) {
      level.classList.add('completed');
      level.classList.remove('active');
    } else if (index === currentLevel - 1) {
      level.classList.add('active');
      level.classList.remove('completed');
    } else {
      level.classList.remove('active', 'completed');
    }
  });

  pathLines.forEach((line, index) => {
    if (index < currentLevel - 1) {
      line.classList.add('active');
    } else {
      line.classList.remove('active');
    }
  });
};

// Move avatar to current level
const moveAvatar = () => {
  const targetLevel = document.getElementById(`level-${currentLevel}`);
  const targetPosition = targetLevel.getBoundingClientRect();
  const containerPosition = document.querySelector('.level-container').getBoundingClientRect();

  const offsetX = targetPosition.left - containerPosition.left + targetLevel.offsetWidth / 2;
  const offsetY = targetPosition.top - containerPosition.top + targetLevel.offsetHeight / 2;

  avatar.style.transform = `translate(${offsetX}px, ${offsetY}px)`;
};

// Handle level completion and animation
document.getElementById('complete-level').addEventListener('click', () => {
  if (currentLevel < levels.length) {
    currentLevel++;
    updateLevels();
    moveAvatar();
    updateProgressBar();
    createConfetti();  // Show confetti when level is completed
  } else {
    alert("Congratulations! All levels completed.");
  }
});

// Initial setup on load
window.addEventListener('load', () => {
  updateLevels();
  moveAvatar();
  updateProgressBar();
});
